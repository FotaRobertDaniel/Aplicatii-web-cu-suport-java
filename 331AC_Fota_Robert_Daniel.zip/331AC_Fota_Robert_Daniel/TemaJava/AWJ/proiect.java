
import java.awt.image.BufferedImage;
import java.io.IOException;

public static void main(String args[]) {

        // variabila folosita in continuare pt inregistrarea timpilor de citire, procesare si scriere imagine
        long startTime;

        // instantiere imagine
        try {
            myInitialImage = new Manipulation(args[0]);
        } catch (IllegalArgumentException ex) {
            System.out.println(ex.getMessage());
            System.exit(0);
        }

        // citire imagine
        try {
            // se memoreaza momentul de timp imediat anterior citirii
            startTime = System.nanoTime();
            myInitialImage.read();
            // se afiseaza timpul de citire, obtinut prin diferenta de timp dintre momentul de timp actual si startTime
            System.out.println("Timp citire:    " + (System.nanoTime() - startTime) + " nanosecunde");
        } catch (IOException ioEx) {
            System.out.println("Citire imagine nereusita! Verificati daca ati introdus bine locatia imaginii.");
            System.exit(0);
        }

        
        // scriere imagine
        myFinalImage = new Manipulation(args[1]);
        try {
            // se inregistreaza timpul de scriere, procedand similar inregistrarii timpului de citire
            startTime = System.nanoTime();
            myFinalImage.write(myInitialImage);
            System.out.println("Timp scriere:   " + (System.nanoTime() - startTime) + " nanosecunde");
            System.out.print("Imagine rotita si salvata! :)");
        } catch (IOException ex) {
            System.out.print("Scriere imagine nereusita!");
        }
    }
}

        