import java.awt.image.BufferedImage;

public Image extends Basic_image{
	
	private String path;
	
	public void Set_path(String path) {this.path=path;}
	public String Get_path() { return path;}
	public void AdjustBrightness(BufferedImage img) {}
	
}