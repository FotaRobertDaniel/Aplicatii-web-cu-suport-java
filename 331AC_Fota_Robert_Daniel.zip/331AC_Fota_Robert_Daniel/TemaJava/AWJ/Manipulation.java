import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public Manipulation extends Image{
	
	//read
	public read() throws IOExceptions{
		Set_img(ImageIO.read(new File(Get_path() ) ) );
	}
	//Write
	public void write(Image img) throws IOException{
		ImageIO.Write(img.Get_img(),".bmp",new File(Get_path()));
	}
	
	//Adjust brightness
	public void AdjustBrightness(BufferedImage img) {}
	
	
}