package test;
import java.io.IOException;
import java.util.Scanner;

import clase.Manipulation;

import java.awt.Desktop;
import java.io.File;

public class Temav2{
@SuppressWarnings("resource")
public static void main(String[] args) throws IOException {


		Manipulation original=null;        	//variabila asupra careia o sa facem modificarile
        long startTime;						//variabila pentru masurat timpii
        String read_path = null;			//variabila pentru citirea locatiei pozei
        int factor = 0;
        Scanner sc=new Scanner(System.in);
        
        //instantiere obiect
        try {
        	System.out.println("Introduceti imaginea sursa:");
        	read_path=sc.nextLine();
            original = new Manipulation(read_path);
        } catch (IllegalArgumentException ex) {
            System.out.println(ex.getMessage());
            System.exit(0);
  
        }
        // citire imagine
        try {
        	
            //se memoreaza timpul cand programul ajunge la linia respectiva
            startTime = System.nanoTime();
            original.read();
            
            // se afiseaza timpul de citire
            System.out.println("Timp citire:    " + (System.nanoTime() - startTime) + " nanosecunde");
        } catch (IOException ioEx) {
            System.out.println("Citire nereusita!");
            System.exit(0);
        }
       
        // citire factor de modificare
        System.out.print("Dati un factor de modificare [-1->-255(mai intunecat),1->255(mai luminat)]:");
        factor=sc.nextInt();
        startTime = System.nanoTime(); //se memoreaza timpul cand programul ajunge la linia respectiva (pt procesare)
       
        //procesare imagine
        original.AdjustBrightness(factor);
        
        // se afiseaza timpul de procesare
        System.out.println("Timp procesare:   " + (System.nanoTime() - startTime) + " nanosecunde");
        
        try {
            // timpul de scriere
            startTime = System.nanoTime();
            original.write(original);
            System.out.println("Timp scriere:   " + (System.nanoTime() - startTime) + " nanosecunde");
        } catch (IOException ex) {}
      
        //deschidere fisier
        File g = new File(read_path+".bmp");
        Desktop dt = Desktop.getDesktop();
        dt.open(g);
        
	}
}
